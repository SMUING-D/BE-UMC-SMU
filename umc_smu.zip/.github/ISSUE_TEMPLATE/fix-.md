---
name: 'FIX '
about: 버그를 수정 및 로직 변경합니다.
title: ''
labels: ''
assignees: ''

---

## Description
설명을 작성해주세요.

## To-do
- [ ] todo
- [ ] todo

## ETC
기타 참고사항을 적어주세요.
