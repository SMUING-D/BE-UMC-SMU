// const jwt = require('jsonwebtoken');
// const mixpanel = require('mixpanel');
// const {  decrypt } = require('../../util/crypter');
// const umcUser = require('../models/umcUser');

// const mixpanelClient = mixpanel.init(process.env.MIXPANEL_TOKEN);

// exports.trackEvent = async(req, res,next)=>{
//     //case 1: 이메일 인증을 했을 경우
// }
